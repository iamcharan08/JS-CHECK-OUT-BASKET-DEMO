# JS-Check-Out-Basket-Demo
 A responsive check out basket demo written in JavaScript, jQuery, HTML5 and CSS3
